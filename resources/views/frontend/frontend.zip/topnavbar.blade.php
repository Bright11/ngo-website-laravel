<div class="top-nav_container">
    {{-- <div class="top-nav_row"> --}}

            <div class="top-logo">
                <img src="{{asset("logo/logo.jpeg")}}" alt="logo" />
            </div>
            <div class="topbaricon-holder">
                <a href="https://www.facebook.com/profile.php?id=100087493599356" title="Facebook"><i class="fa fa-facebook topicons"></i></a>
                <a href=""><i class="fa fa-twitter-square topicons" title="Twitter"></i></a>
                <a href=""> <i class="fa fa-youtube-play topicons" title="Youtube"></i></a>
                <a href=""> <i class="fa fa-instagram topicons" title="Instagram"></i></a>

            </div>

            <div class="call">
                <a href="tel:+233244834446" class="phonenumber-class" title="Call"> <i class="fa fa-phone topicons"></i>+233244834446</a>
            </div>
        {{-- </div> --}}

</div>
